// 这里我仅仅加载了模块中的 square 成员
import { square } from './math.js'

const ret = square(10)

console.log(ret)
