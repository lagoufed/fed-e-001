const a = 123

export function square(x) {
  console.log('square start')
  return x * x

  console.log('seuare end')
}

export function cube(x) {
  console.log('cube')
  return x * x * x
}
